let app = new Vue({
  el: '.wapper',
  data: {
    serachContent: '',
    songs: '',
    placeholder: '薛之谦',
    songId: '',
    audioUrl: '',
    play: '',
    playingBtn: true,
    pausingBtn: false,
    minImgSrc: '',
    minSong: '',
    minSonger: '',
    minAudioIsShow: false
  },
  methods: {
    serach: function () {
      //如果没有输入内容，则搜索占位符
      if (this.serachContent === '') {
        this.serachContent = this.placeholder
      }
      var thisSongs = this
      $.ajax({
        url: 'https://v2.alapi.cn/api/music/search',
        type: 'get',
        data: {
          token: '36JffH6R63o8ZFTD',
          //搜索的关键字
          keyword: this.serachContent,
          // 搜索类型 默认为 1 即单曲 , 取值意义 :1: 单曲, 10: 专辑, 100: 歌手, 1000: 歌单, 1002: 用户, 1004: MV, 1006: 歌词, 1009: 电台, 1014: 视频, 1018:综合
          type: 1,
          //单页数量
          limit: 20
        },
        success(res) {
          thisSongs.songs = res.data.songs
        },
        error() {
          console.log('error');
        }
      })
    },
    playMusic: function (musicId) {
      var that = this
      //点击歌单列表某一首歌播放
      $.ajax({
        url: 'https://v2.alapi.cn/api/music/url',
        type: 'get',
        data: {
          token: '36JffH6R63o8ZFTD',
          id: musicId,
          contentType: 'jsonp',
          format: 'json'
        },
        success(res) {
          that.minAudioIsShow = true
          initMinfontSize()
          that.audioUrl = res.data.url
          // console.log(res.data);
          that.play = 'autoplay'
          this.playingBtn = true
          this.pausingBtn = false
          // 执行进度条
          // beginProgress()
          beginCirProgress()
        },
        error() {
          console.log('error');
        }
      })
      //点击一首歌获取该歌信息
      $.ajax({
        url: 'https://v2.alapi.cn/api/music/detail',
        type: 'get',
        data: {
          token: '36JffH6R63o8ZFTD',
          id: musicId
        },
        success(res) {
          that.minImgSrc = res.data.songs[0].al.picUrl
          that.minSong = res.data.songs[0].name
          that.minSonger = res.data.songs[0].ar[0].name
        },
        error() {
          console.log('error');
        }
      })

    },
    // 点击小窗口按钮控制播放与暂停
    minPlayOrPause: function () {
      //audio标签的属性：播放：play() 暂停：pause() 
      //paused 返回true表示暂停播放，false表示正在播放
      var playBtn = document.querySelector('audio')
      if (playBtn.paused) {
        //进度条动画继续执行
        $('.rightcircle').css('animationPlayState', 'running')
        $('.leftcircle').css('animationPlayState', 'running')
        playBtn.play()
        this.playingBtn = !this.playingBtn
        this.pausingBtn = !this.pausingBtn
      } else {
        //进度条动画暂停
        $('.rightcircle').css('animationPlayState', 'paused')
        $('.leftcircle').css('animationPlayState', 'paused')
        playBtn.pause()
        this.playingBtn = !this.playingBtn
        this.pausingBtn = !this.pausingBtn
      }
    },
    //音乐播放结束
    musicEnded:function () {
      console.log('音乐播放结束');
    }
  }
})

// 获取音频时间并执行直线进度条
function beginProgress() {
  $('.progressBar').css('display', 'none')
  var aud = $(".myAudio")[0];
  // oncanplay:source标签的属性 在音频开始时执行函数
  // duration：source标签的属性 音频的时长
  aud.oncanplay = function () {
    // console.log("myVid.duration==" + aud.duration);
    // console.log($('.progressBar').css('animationDuration'))
    // 显示并设置进度条动画时间
    $('.progressBar')
      .css('display', 'block')
      .css('animationDuration', aud.duration + 's')
  }
}
// 获取音频时间并执行圆形进度条
function beginCirProgress() {
  console.log('yes');
  $('.circleProgress_wrapper').css('display', 'none')
  var aud = $(".myAudio")[0];
  // oncanplay:source标签的属性 在音频开始时执行函数
  // duration：source标签的属性 音频的时长
  aud.oncanplay = function () {
    console.log("myVid.duration==" + aud.duration);
    // console.log($('.progressBar').css('animationDuration'))
    // 显示并设置进度条动画时间
    $('.circleProgress_wrapper').css('display', 'block')
    $('.rightcircle')
      .css('animationDuration', aud.duration + 's')
    $('.leftcircle')
      .css('animationDuration', aud.duration + 's')
  }
}

//解决歌名过长导致换行问题
var initMinfontSize = () => {
  $(document).ready(function () {
    // 获取p1的字数
    var wordNumber = $(".p1").html().length;
    // console.log(wordNumber);
    var fontSize = wordNumber > 5 ? '0.6rem' : '0.9rem';
    $(".p1").css('font-size', fontSize)
  });

}
